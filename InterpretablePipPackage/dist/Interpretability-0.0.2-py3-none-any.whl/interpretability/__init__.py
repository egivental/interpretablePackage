from .SLIMCLASS import SLIM as SLIM
#from .BOACLASS import SLIM
from .CORELSCLASS import CORELS as CORELS